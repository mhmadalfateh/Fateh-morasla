package com.fateh.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF061525)
private val Panel = Color(0xFF10283D)
private val Blue = Color(0xFF079BFF)
private val Cyan = Color(0xFF22C7F5)
private val White = Color(0xFFEAF5FF)
private val Muted = Color(0xFF9BB4C9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FatehApp(onExit = { finish() }) }
    }
}

data class ChatMessage(val text: String, val mine: Boolean)
data class Contact(val name: String, val code: String, val preview: String)

@Composable
fun FatehApp(onExit: () -> Unit) {
    var page by remember { mutableStateOf("welcome") }
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("MF82K7Q") }
    var hideName by remember { mutableStateOf(false) }
    var lockEnabled by remember { mutableStateOf(false) }
    var archived by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Contact?>(null) }
    var draft by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(ChatMessage("أهلاً بك في فاتح ماسنجر", false)) }
    val contacts = remember { mutableStateListOf(Contact("صديق تجريبي", "FRIEND42", "أهلاً بك في التطبيق")) }

    BackHandler(enabled = page != "welcome") {
        page = when (page) { "chat" -> "home"; "settings", "archive", "add" -> "home"; else -> "welcome" }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Panel, onSurface = White)) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            when (page) {
                "welcome" -> Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Image(painter = painterResource(id = R.drawable.fateh_cover), contentDescription = "غلاف فاتح ماسنجر", modifier = Modifier.fillMaxWidth().height(210.dp), contentScale = ContentScale.Crop)
                    Spacer(Modifier.height(18.dp))
                    Box(Modifier.size(72.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Chat, null, tint = Blue, modifier = Modifier.size(44.dp)) }
                    Spacer(Modifier.height(14.dp)); Text("فاتح ماسنجر", color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("مراسلة بخصوصية وبساطة", color = Muted, modifier = Modifier.padding(top = 8.dp))
                    Spacer(Modifier.height(34.dp)); PrimaryButton("ابدأ الآن") { page = "profile" }
                    Spacer(Modifier.height(26.dp)); Text("المطوّر: محمد الفاتح", color = Cyan); Text("الإصدار 1.0", color = Muted, fontSize = 12.sp)
                }
                "profile" -> Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Header("إنشاء ملفك", onBack = { page = "welcome" }); Spacer(Modifier.height(24.dp))
                    Text("كود الإضافة الخاص بك", color = Muted); Text(code, color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("هذا كود تجريبي حالياً؛ بعد ربط الخادم سيصبح فريداً لكل حساب.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 10.dp))
                    Field(name, { name = it }, "اسم المستخدم (اختياري)")
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(hideName, { hideName = it }); Text("إخفاء الاسم", color = White) }
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(lockEnabled, { lockEnabled = it }); Text("أريد كلمة سر للتطبيق (اختياري)", color = White) }
                    Spacer(Modifier.height(20.dp)); PrimaryButton("دخول إلى المحادثات") { page = "home" }
                    Spacer(Modifier.height(12.dp)); Text("تنبيه: الحسابات والمراسلة تحتاج إلى إعداد خادم قبل الاستخدام الحقيقي.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                }
                "home" -> Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column { Text("محادثاتي", color = White, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("كودك: $code", color = Cyan, fontSize = 13.sp) }
                        IconButton(onClick = { page = "settings" }) { Icon(Icons.Default.Settings, "الإعدادات", tint = Cyan) }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PrimaryButton("＋ إضافة بالكود", Modifier.weight(1f)) { page = "add" }
                        OutlinedButton(onClick = { archived = !archived; page = "archive" }) { Text("الأرشيف", color = Cyan) }
                    }
                    Spacer(Modifier.height(12.dp))
                    val shown = if (archived) emptyList() else contacts.toList()
                    if (shown.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(if (archived) "لا توجد محادثات مؤرشفة" else "لا توجد محادثات بعد", color = Muted) }
                    else LazyColumn { items(shown) { c -> Row(Modifier.fillMaxWidth().clickable { selected = c; page = "chat" }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Cyan) }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(if (hideName) "مستخدم" else c.name, color = White, fontWeight = FontWeight.SemiBold); Text(c.preview, color = Muted, fontSize = 13.sp) }
                        IconButton(onClick = { contacts.remove(c); archived = true; page = "archive" }) { Icon(Icons.Default.Archive, "أرشفة", tint = Muted) }
                    } } }
                    Text("واجهة أولية — المراسلة ليست متصلة بخادم بعد", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center)
                }
                "add" -> Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Header("إضافة صديق بالكود") { page = "home" }; var friendCode by remember { mutableStateOf("") }
                    Spacer(Modifier.height(22.dp)); Field(friendCode, { friendCode = it }, "أدخل كود الشخص")
                    Spacer(Modifier.height(14.dp)); PrimaryButton("إضافة") { if (friendCode.isNotBlank()) { contacts.add(Contact("مستخدم جديد", friendCode.trim().uppercase(), "تمت الإضافة محلياً — يلزم ربط الخادم")); page = "home" } }
                    Text("حالياً تتم الإضافة محلياً فقط، ولن تصل الرسائل إلى هاتف آخر قبل إعداد خدمة خلفية.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 16.dp))
                }
                "chat" -> Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { page = "home" }) { Icon(Icons.Default.ArrowBack, "رجوع", tint = Cyan) }
                        Column(Modifier.weight(1f)) { Text(if (hideName) "مستخدم" else (selected?.name ?: "محادثة"), color = White, fontWeight = FontWeight.Bold); Text(selected?.code ?: "", color = Muted, fontSize = 12.sp) }
                        IconButton(onClick = { archived = true; page = "home" }) { Icon(Icons.Default.Archive, "أرشفة", tint = Cyan) }
                    }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp)) { items(messages) { m -> Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) { Text(m.text, color = White, modifier = Modifier.padding(vertical = 5.dp).background(if (m.mine) Color(0xFF075C9A) else Panel, RoundedCornerShape(16.dp)).padding(12.dp)) } } }
                    Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {}) { Icon(Icons.Default.Image, "صورة (يتطلب ربط التخزين)", tint = Cyan) }
                        IconButton(onClick = {}) { Icon(Icons.Default.Mic, "صوت (يتطلب تنفيذ التسجيل)", tint = Cyan) }
                        BasicTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f).background(Navy, RoundedCornerShape(18.dp)).padding(12.dp), textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 14.sp), decorationBox = { inner -> if (draft.isEmpty()) Text("اكتب رسالة...", color = Muted); inner() })
                        IconButton(onClick = { if (draft.isNotBlank()) { messages.add(ChatMessage(draft, true)); draft = "" } }) { Icon(Icons.Default.Send, "إرسال", tint = Blue) }
                    }
                }
                "archive" -> Column(Modifier.fillMaxSize().padding(20.dp)) { Header("الأرشيف") { page = "home" }; Text("الأرشيف في هذه النسخة واجهة أولية فقط.", color = Muted, modifier = Modifier.padding(top = 18.dp)) }
                "settings" -> Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Header("الإعدادات") { page = "home" }; Spacer(Modifier.height(16.dp))
                    Text("الخصوصية", color = Cyan, fontSize = 18.sp); Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(hideName, { hideName = it }); Text("إخفاء الاسم", color = White) }
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(lockEnabled, { lockEnabled = it }); Text("كلمة سر اختيارية (واجهة فقط حالياً)", color = White) }
                    Spacer(Modifier.height(12.dp)); Text("المطوّر: محمد الفاتح", color = White); Text("لجعل الحسابات والرسائل حقيقية، يجب ربط Firebase أو خادم مماثل.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(24.dp)); OutlinedButton(onClick = { page = "welcome" }, modifier = Modifier.fillMaxWidth()) { Text("العودة إلى القائمة الرئيسية", color = Cyan) }; Spacer(Modifier.height(8.dp)); Button(onClick = onExit, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB52E48))) { Text("الخروج من التطبيق") }
                }
            }
        }
    }
}

@Composable private fun Header(title: String, onBack: () -> Unit) { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "رجوع", tint = Cyan) }; Text(title, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold) } }
@Composable private fun Field(value: String, onValueChange: (String) -> Unit, hint: String) { BasicTextField(value, onValueChange, modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp).background(Panel, RoundedCornerShape(12.dp)).padding(16.dp), textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 16.sp), decorationBox = { inner -> if (value.isEmpty()) Text(hint, color = Muted); inner() }) }
@Composable private fun PrimaryButton(text: String, modifier: Modifier = Modifier.fillMaxWidth(), onClick: () -> Unit) { Button(onClick = onClick, modifier = modifier.height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue), shape = RoundedCornerShape(14.dp)) { Text(text, color = Color.White, fontWeight = FontWeight.Bold) } }
